---
created: 2024-01-05T00:00:00Z
tags: [notes]
---

# Single Page

A standalone Notion page.
